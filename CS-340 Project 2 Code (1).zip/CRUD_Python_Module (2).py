from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
    
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]
    
    def create(self, data):
        if isinstance(data, dict):
            if data:  # makes sure that data is not empty
                result = self.collection.insert_one(data)  # Insert document
                return True if result.inserted_id else False  # Check success
            else:
                raise ValueError("Nothing to save, data parameter is empty")
        else:
            print("Invalid input type")
    
    def read(self, query):
        if isinstance(query, dict):
            try:
                documents = list(self.collection.find(query))  # Execute query
                return documents if documents else []  # Return a list of results
            except Exception as e:
                print(f"Error reading from database: {e}")
                return []
        else:
            print("Invalid input type")
    
    def update(self, query, new):
        if isinstance(query, dict) and isinstance(new, dict):
            try:
                result = self.collection.update_many(query, new) #queries all with matching information and updates them with the new information
                return result.modified_count #outputs the number of modified entries
            except:
                return "Error: Unable to update documents."
        else:
            print("Invalid input type")

    def delete(self, query):
        if isinstance(query, dict):
            try:
                result = self.collection.delete_many(query) #queries all with matching information and deltes those entries
                return result.deleted_count #outputs the number of deleted entries
            except:
                return "Error: Unable to delete documents."
        else:
            print("Invalid input type")